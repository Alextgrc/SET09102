﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _40219741_set09102;

namespace _40219741_testUnit
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testInputTweet()
        {
            var mainWindow = new MainWindow();
            string inputTweet = "Twitter ID";
            var r = mainWindow.checkMessegeTweet(inputTweet);

            Assert.IsTrue(r);

        }
        [TestMethod]
        public void testInputSMS()
        {
            var mainWindow = new MainWindow();
            string inputsms = "SMS";
            var r = mainWindow.checkMessegeSMS(inputsms);

            Assert.IsTrue(r);

        }
        [TestMethod]
        public void testInputEmail()
        {
            var mainWindow = new MainWindow();
            string inputemail = "E-mail";
            var r = mainWindow.checkMessegeEmail(inputemail);

            Assert.IsTrue(r);

        }

        [TestMethod]
        public void testIDTweet()
        {
            var mainWindow = new MainWindow();
            string inputsender = "Twitter ID";
            int tweetID = 112233445;
            var r = mainWindow.checkMessageID(inputsender, tweetID);

            Assert.AreEqual(1, r);

        }
        [TestMethod]
        public void testIDSMS()
        {
            var mainWindow = new MainWindow();
            string inputsender = "SMS";
            int SMS = 112233445;
            var r = mainWindow.checkMessageID(inputsender, SMS);

            Assert.AreEqual(2, r);

        }
        [TestMethod]
        public void testIDEmail()
        {
            var mainWindow = new MainWindow();
            string inputsender = "E-mail";
            int emailID = 112233445;
            var r = mainWindow.checkMessageID(inputsender, emailID);

            Assert.AreEqual(3, r);

        }
    }
}
